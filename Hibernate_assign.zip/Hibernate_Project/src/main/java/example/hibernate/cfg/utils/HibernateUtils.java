package example.hibernate.cfg.utils;

import org.hibernate.cfg.Configuration;

import org.hibernate.SessionFactory;

public class HibernateUtils {
	public static SessionFactory getSessionFactory() {
		Configuration conf=new Configuration();
		conf = conf.configure();
		SessionFactory fact=conf.buildSessionFactory();
		return fact;
		
	}
}
