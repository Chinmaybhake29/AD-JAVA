package example.hibernate.entity;

public class Moive {
	private String moiveid;
	private String title;
	private String genre;
	private int year;
	
		public Moive() {
			
		}

		public Moive(String moiveid, String title, String genre,int year) {
			super();
			this.moiveid = moiveid;
			this.title = title;
			this.genre = genre;
			this.year=year;
			
		}

		public String getMoiveid() {
			return moiveid;
		}

		public void setMoiveid(String moiveid) {
			this.moiveid = moiveid;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getGenre() {
			return genre;
		}

		public void setGenre(String genre) {
			this.genre = genre;
		}
		public int getYear() {
			return year;
		}

		public void setYear(int genre) {
			this.year = genre;
		}
		
}
