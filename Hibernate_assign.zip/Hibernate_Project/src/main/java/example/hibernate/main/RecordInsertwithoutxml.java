package example.hibernate.main;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import example.hibernate.cfg.utils.HibernateUtilities;
import example.hibernate.cfg.utils.HibernateUtils;
import example.hibernate.entity.Actor;
import org.hibernate.*;

public class RecordInsertwithoutxml {
			public static void main(String[] args) {
				try(SessionFactory factory=HibernateUtilities.getSessionFactory();
					Session s=factory.openSession()){
					Actor a=new Actor("A01","Kartik","Aryan",38);
					Transaction tx=s.beginTransaction();
					s.persist(tx);
					tx.commit();
					System.out.println("Record Added");
				}
				catch (Exception e) {
					// TODO: handle exception
				}
			}
}
