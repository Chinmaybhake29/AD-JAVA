package example.hibernate.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import example.hibernate.cfg.utils.HibernateUtilities;
import example.hibernate.entity.Moive;

public class RecordRetrivalExample {
	public static void main(String[] args) {
		try(SessionFactory factory=HibernateUtilities.getSessionFactory();
			Session session=factory.openSession();
			){
			
			//Loading an entity of type:Movie Against an ID: A06
			Moive m=session.find(Moive.class, "M01");
			System.out.println("Found Movie: "+m);
			System.out.println("Movie Name: " + m.getTitle());
			
		} catch (Exception e) {
			
		}
	}
}
