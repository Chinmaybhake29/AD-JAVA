package example.hibernate.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import example.hibernate.cfg.utils.HibernateUtilities;
import example.hibernate.entity.Moive;
import org.hibernate.Transaction;
import org.hibernate.*;
public class RecordUpdationExample {
		public static void main(String[] args) {
			try(SessionFactory factory=HibernateUtilities.getSessionFactory();
				Session session=factory.openSession();
					){
				
			Moive found=session.find(Moive.class, "M01");
			Transaction tx=session.beginTransaction();
			found.setMoiveid("M01");
			found.setYear(2015);
			
				
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
}
