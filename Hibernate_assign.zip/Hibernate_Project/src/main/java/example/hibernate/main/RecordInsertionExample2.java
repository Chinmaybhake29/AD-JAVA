package example.hibernate.main;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import example.hibernate.cfg.utils.*;
import example.hibernate.entity.Moive;
import jakarta.transaction.Transaction;

public class RecordInsertionExample2 {
	
	public static void main(String[] args) {
		try(SessionFactory factory= HibernateUtils.getSessionFactory();
		Session session=factory.openSession()){
			Moive obj=new Moive("M03", "DON", "Crime", 2006);
			org.hibernate.Transaction tx=session.beginTransaction();
			session.persist(obj);
			tx.commit();
			System.out.println("record Inserted");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
