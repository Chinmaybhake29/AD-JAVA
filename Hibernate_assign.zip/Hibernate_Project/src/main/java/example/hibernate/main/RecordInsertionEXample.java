package example.hibernate.main;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import example.hibernate.entity.*;
import org.hibernate.*;
public class RecordInsertionEXample {

	public static void main(String[] args) {
		//Configure Hibernate using 'Configuration' class
		Configuration conf=new Configuration();
		
		//Obtain SessionFactory using 'Configuration' class
		conf=conf.configure();
		
		//Obtain a session using SessionFcatory
		SessionFactory fact=conf.buildSessionFactory();
		
		Session currentSession=fact.openSession();
		
		
		Moive moiveObj=new Moive("M01","Baby","Action",2015);
		Moive moiveObj1=new Moive("M02","Singham","Action",2011);

		
		//obtain the transaction and start the same
		Transaction tx=currentSession.beginTransaction();
		
		currentSession.persist(moiveObj);
		currentSession.persist(moiveObj1);
		
		tx.commit();
		
		currentSession.close();
		fact.close();
		System.out.println("Record Inserted Sucessfully!");
		
	}

}
