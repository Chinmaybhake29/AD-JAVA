package example.hibernate.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import example.hibernate.cfg.utils.HibernateUtilities;
import example.hibernate.entity.Moive;
import org.hibernate.Transaction;

public class RecordDeleteExample {
	public static void main(String[] args) {
		try(
			SessionFactory factory=HibernateUtilities.getSessionFactory();
			Session session=factory.openSession();){
			
			Moive m=session.find(Moive.class, "M01");
			Transaction tx=session.beginTransaction();
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
